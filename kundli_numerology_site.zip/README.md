# Kundli + Numerology + Lal Kitab Report Generator
Instructions inside.